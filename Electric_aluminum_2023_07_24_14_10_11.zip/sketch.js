
  

function setup() {
  createCanvas(600, 600);
  background("white");
}

function draw() {
  stroke("rgb(27,2,2)");
  fill("rgb(68,255,0)");

  // console.log(mouseIsPressed)

  if (mouseIsPressed) {
    rect(mouseX, mouseY, 20, 35);
  }
}